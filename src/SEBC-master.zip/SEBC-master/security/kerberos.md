# SEBC
Services Enablement Boot Camp
https://blog.puneethabm.com/configure-hadoop-security-with-cloudera-manager-using-kerberos/